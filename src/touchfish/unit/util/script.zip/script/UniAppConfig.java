package touchfish.unit.util.script;

import java.io.File;

public class UniAppConfig {

    public static final String locatePath = "E:\\HBuilderX\\HBuilderProjects\\ManagerTemplate";
    
    public static File source = new File(locatePath);

}
