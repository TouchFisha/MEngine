package touchfish.unit.test;

import java.io.IOException;

public class HTTPTemplateCacheServer {
    
    private final int port;
    private final CacheStorage cacheStorage;
    private Server server;
    
    public HTTPTemplateCacheServer(int port, CacheStorage cacheStorage) {
        this.port = port;
        this.cacheStorage = cacheStorage;
    }
    
    public void start() throws IOException {
        Server server = new Server(port);
        ServletContextHandler context = new ServletContextHandler(server, "/");
        context.addServlet(TemplateCacheServlet.class, "/*");
        server.start();
        this.server = server;
    }
    
    public void stop() throws Exception {
        server.stop();
    }
    
    public static class TemplateCacheInfo {
        public long lastModified;
    }
    
    public static class TemplateCacheServlet extends HttpServlet {
        // ...
    }
}