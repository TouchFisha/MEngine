package touchfish.unit.test;

import java.util.HashMap;
import java.util.Locale;
import java.util.Properties;
import java.util.TimeZone;
import java.util.concurrent.ConcurrentHashMap;

public class Configuration {
    
    // 版本号
    public static final String VERSION_2_3_23 = "2.3.23";
    
    // 模板加载器
    private TemplateLoader templateLoader;
    
    // 默认配置
    private Properties defaultProperties;
    
    //  Settings
    private Settings settings; 
    
    // 构造方法
    public Configuration() {
        this(VERSION_2_3_23);
    }

    public Configuration(Version version) {
        if (version == null) {
            throw new TemplateModelException("The 'version' parameter cannot be null.");
        }
        this.version = version;
        this.defaultProperties = new Properties();
        this.templateCache = new ConcurrentHashMap<>();
        this.objectWrapper = ObjectWrapper.DEFAULT_WRAPPER;
        this.templateLoader = null;
        this.cacheStorage = null;
        this.locale = Locale.getDefault();
        this.timeZone = TimeZone.getDefault();
        this.customAttributes = new HashMap<>();
        this.cacheable = true;
        this.booleanFormat = "true,false";
        this.classicCompatible = false;
        this.logTemplateExceptions = true;
        this.wrapUncheckedExceptions = true;

        SettingsBuilder settingsBuilder = new SettingsBuilder(version);
        if (version.compareTo(VERSION_2_3_27) < 0) {
            settingsBuilder.setCacheStorage(new DefaultCacheStorage(this));
        }
        this.settings = settingsBuilder.build();
    }

    // 设置模板加载器
    public void setTemplateLoader(TemplateLoader templateLoader) {
        this.templateLoader = templateLoader;
    }
    
    // 获取模板
    public Template getTemplate(String name) {
        Template template = templateCache.get(name);
        if (template == null) {
            template = createTemplate(name, null);
            templateCache.put(name, template);
        }
        return template;
    }
    
    // 获取模板 
    public Template getTemplate(String name, Encoding encoding) {
        // ...
    }
    
    // 获取设置
    public Settings getSettings() {
        return settings;
    } 
}