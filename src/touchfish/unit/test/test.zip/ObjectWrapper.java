package touchfish.unit.test;

public interface ObjectWrapper {

    public static final String DEFAULT_WRAPPER_KEY = "default_object_wrapper";

    /**
     * Wraps the object for template usage. The returned object should be:
     * <ul>
     *   <li>XML-safe (so it's okay to output it without escaping)
     *   <li>Adequately formatted (for example JavaBeans are converted to maps, Date-s are formatted, etc.)
     *   <li>Contain no cyclic references
     *   <li>User-friendly/client code friendly in terms of type conversions (for example NULL is converted to empty string) 
     * </ul>  
     * 
     * @param object The object to wrap
     * @return The wrapped object. Can't be null.
     */
    Object wrap(Object object);
}