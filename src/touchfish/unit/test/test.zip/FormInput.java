package touchfish.unit.test;

public class FormInput {
    private String name;         // 表单项名称
    private String type;        // 表单项类型 
    private boolean required;   // 是否必填
    private String defaultValue;// 默认值
    private String rules;       // 校验规则
    private String label;       // 表单项 label
    
    // getter和setter方法...
    
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    
    public String getType() {
        return type; 
    }
    public void setType(String type) {
        this.type = type;
    }
    
    public boolean isRequired() {
        return required;
    }
    public void setRequired(boolean required) {
        this.required = required;
    }
    
    public String getDefaultValue() {
        return defaultValue;
    }
    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }
    
    public String getRules() {
        return rules;
    }
    public void setRules(String rules) {
        this.rules = rules;
    }
    
    public String getLabel() {
        return label; 
    }
    public void setLabel(String label) {
        this.label = label;
    } 
}