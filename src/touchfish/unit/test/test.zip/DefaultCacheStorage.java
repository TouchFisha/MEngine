package touchfish.unit.test;

import java.io.File;
import java.io.IOException;

public class DefaultCacheStorage implements CacheStorage {

    private final File cacheDir;
    private final String cacheId;

    public DefaultCacheStorage(File cacheDir) {
        this(cacheDir, null);
    }

    public DefaultCacheStorage(File cacheDir, String cacheId) {
        cacheDir.mkdirs();
        this.cacheDir = cacheDir;
        this.cacheId = cacheId;
    }

    public void putTemplate(Template template, long lastModified) throws IOException {
        // ...
    }

    public Template getTemplate(String name, long lastModified, TemplateLoader templateLoader,  
            HTTPTemplateCacheServer.TemplateCacheInfo templateCacheInfo) throws IOException {
        // ...
    }

    public void removeTemplate(String name) {
        // ... 
    }

    public void clear() {
        // ...
    }
}