package touchfish.unit.test;

import java.util.Collection;
import java.util.Date;
import java.util.Map;

public class DefaultObjectWrapper extends BeansWrapper implements ObjectWrapper {

    public static final DefaultObjectWrapper INSTANCE = new DefaultObjectWrapper();

    public DefaultObjectWrapper() {
        setSimpleMapWrapper(false);
    }

    public Object wrap(Object obj) throws TemplateModelException {
        if (obj == null) {
            return "";
        } else if (obj instanceof TemplateModel) {
            return obj;
        } else if (obj instanceof String) {
            return obj;
        } else if (obj instanceof Number) {
            return obj;
        } else if (obj instanceof Boolean) {
            return obj;
        } else if (obj instanceof Date) {
            return new SimpleDate((Date) obj, objectWrapperConfiguration.getDateFormat());
        } else if (obj instanceof Map) {
            return wrapMap((Map) obj); 
        } else if (obj instanceof Collection) {
            return wrapCollection((Collection) obj);
        } else if (obj.getClass().isArray()) {
            return wrapArray(obj);
        } else {
            return wrapBean(obj);
        }
    }
} 