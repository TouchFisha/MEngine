package touchfish.unit.test;

public interface Settings {
    // Empty
}