package touchfish.unit.test;

import java.io.IOException;
import java.io.Reader;

public interface TemplateLoader {
    
    Object findTemplateSource(String name);
    
    Reader getReader(Object templateSource, String encoding) throws IOException;
    
    void closeTemplateSource(Object templateSource) throws IOException;
}