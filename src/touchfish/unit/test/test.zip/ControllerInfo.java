package touchfish.unit.test;

import sun.management.MethodInfo;

import java.util.List;

public class ControllerInfo {
    private String controllerName;  // Controller名称
    private String path;           // 请求路径
    private String componentName;  // 组件名称
    private List<MethodInfo> methods; // 方法信息列表
    private List<TypeInfo> types;   // 类型信息列表
    private List<FormInput> formInputs; // 表单项信息列表
    private List<String> imports;   // 导入信息列表

}