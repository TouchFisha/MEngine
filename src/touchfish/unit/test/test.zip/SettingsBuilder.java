package touchfish.unit.test;

import java.util.Properties;

public final class SettingsBuilder {
    
    private Version version;
    private Properties properties;
    
    public SettingsBuilder(Version version) {
        this.version = version;
        this.properties = new Properties();
    }
    
    public SettingsBuilder setSetting(String name, String value) {
        properties.put(name, value);
        return this;
    }
    
    public SettingsBuilder setCacheStorage(CacheStorage cacheStorage) {
        properties.put(CacheStorage.CACHE_STORAGE_KEY, cacheStorage);
        return this;
    }
    
    public Settings build() {
        return new DefaultSettings(properties, version);
    }
}