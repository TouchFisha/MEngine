package touchfish.unit.test;

public class Version implements Comparable<Version> {
    
    private int major;
    private int minor;
    private int revision;
    private int[] qualifier;
    
    public Version(int major, int minor, int revision) {
        this(major, minor, revision, null);
    }
    
    public Version(int major, int minor, int revision, int[] qualifier) {
        this.major = major;
        this.minor = minor;
        this.revision = revision;
        this.qualifier = qualifier;
    }
    
    public int getMajor() {
        return major;
    }
    
    public int getMinor() {
        return minor; 
    }
    
    public int getRevision() {
        return revision;
    }  
    
    public int[] getQualifier() {
        return qualifier;
    } 
    
    public int compareTo(Version other) {
        return 0;
    }
}