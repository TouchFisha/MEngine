package touchfish.unit.test;

import java.io.IOException;

public interface CacheStorage {

    String CACHE_STORAGE_KEY = "freemarker.cache.storage";

    void putTemplate(Template template, long lastModified);

    Template getTemplate(String name, long lastModified, TemplateLoader templateLoader, HTTPTemplateCacheServer.TemplateCacheInfo templateCacheInfo) throws IOException;

    void removeTemplate(String name);

    void clear();
}