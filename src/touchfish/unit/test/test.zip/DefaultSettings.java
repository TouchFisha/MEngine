package touchfish.unit.test;

import java.util.Properties;

public class DefaultSettings implements Settings {
    
    private final Properties properties;
    private final Version version;
    
    public DefaultSettings(Properties properties, Version version) {
        this.properties = properties;
        this.version = version;
    }
    
    public String getSetting(String name) {
        return properties.getProperty(name);
    }
    
    public Version getVersion() {
        return version; 
    }
} 