package touchfish.unit.test;

import sun.reflect.FieldInfo;

import java.util.List;

public class TypeInfo {
    private String name;         // 类型名称
    private String type;        // 类型
    private boolean isArray;    // 是否数组类型
    private List<FieldInfo> fields;   // 字段列表
    
    // getter和setter方法...
    
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    
    public boolean isArray() {
        return isArray; 
    }
    public void setArray(boolean array) {
        isArray = array;
    }
    
    public List<FieldInfo> getFields() {
        return fields;
    }
    public void setFields(List<FieldInfo> fields) {
        this.fields = fields;
    }
}