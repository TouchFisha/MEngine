package touchfish.unit.test;

import sun.misc.IOUtils;

import java.io.*;
import java.util.Map;

public class Template {
    /**
     * 渲染Vue页面模板
     */
    public static void renderVuePageTemplate(Map<String, ControllerInfo> controllers,
                                             String templatePath, String viewPath) throws IOException {
        File templateFile = new File(templatePath + "/Page.vue");
        String template = readFileToString(templateFile, "UTF-8");
        for (String controllerName : controllers.keySet()) {
            ControllerInfo info = controllers.get(controllerName);
            // 渲染模板
            String content = TemplateEngine.render(template, info);
            // 写入文件
            write(new File(viewPath + "/" + controllerName + "/Page.vue"), content, "UTF-8");
        }
    }

    public static void write(File file, String content, String encoding) throws IOException {
        FileOutputStream outputStream = new FileOutputStream(file);
        try {
            OutputStreamWriter writer = new OutputStreamWriter(outputStream, encoding);
            writer.write(content);
        } finally {
            outputStream.close();
        }
    }

    public static String readFileToString(File file, String encoding) throws IOException {
        InputStream inputStream = new FileInputStream(file);
        String text = toString(inputStream, encoding);
        inputStream.close();
        return text;
    }
    
    public static String toString(InputStream inputStream, String encoding) throws IOException {
        StringBuilder sb = new StringBuilder();
        try {
            InputStreamReader reader = new InputStreamReader(inputStream, encoding);
            char[] buffer = new char[4096];
            int n;
            while ((n = reader.read(buffer)) != -1) {
                sb.append(buffer, 0, n);
            }
        } finally {
            inputStream.close();
        }
        return sb.toString();
    }

    // 渲染表单、接口、入口、类型定义、ElementUI表单配置 模板
    // ... 代码省略 
    
    public static void renderVueFormTemplate(Map<String, ControllerInfo> controllers, 
                                     String templatePath, String viewPath) {
       // ... 
    }
    
    public static void renderApiTemplate(Map<String, ControllerInfo> controllers, 
                                     String templatePath, String viewPath) {
       // ... 
    }
    
    public static void renderEntryTemplate(Map<String, ControllerInfo> controllers, 
                                     String templatePath, String viewPath) {
       // ...
    }
    
    public static void renderTsTypeTemplate(Map<String, ControllerInfo> controllers,
                                     String templatePath, String viewPath) {
       // ...
    }
    
    public static void renderEleFormConfigTemplate(Map<String, ControllerInfo> controllers, 
                                     String templatePath, String viewPath) {
        // ...
    } 
}