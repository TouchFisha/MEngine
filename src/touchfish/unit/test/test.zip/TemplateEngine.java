package touchfish.unit.test;

import java.io.StringWriter;

public class TemplateEngine {
    public static String render(String template, Object info) {
        Configuration config = new Configuration(Configuration.VERSION_2_3_23);
        config.setClassForTemplateLoading(TemplateEngine.class, "/templates");
        Template t = config.getTemplate(template);
        
        StringWriter writer = new StringWriter();
        try {
            t.process(info, writer);
        } catch (TemplateException e) {
            e.printStackTrace();
        }
        return writer.toString();
    }
    
    public static void generate(Map<String, Object> dataModel, Writer out) {
        Configuration config = new Configuration(Configuration.VERSION_2_3_23);
        config.setClassForTemplateLoading(TemplateEngine.class, "/templates");  
        
        try {
            Template template = config.getTemplate("index.ftl");
            template.process(dataModel, out);
        } catch (TemplateException e) {
            e.printStackTrace(); 
        }
    }
    
    public static String renderString(String templateString, Object info) {
        StringWriter writer = new StringWriter();
        renderString(templateString, info, writer);
        return writer.toString();
    }
    
    public static void renderString(String templateString, Object info, Writer out) {
        Configuration config = new Configuration(Configuration.VERSION_2_3_23);
        config.setClassForTemplateLoading(TemplateEngine.class, "/templates"); 
        Template template = new Template("template name", templateString, config);
        
        try {
            template.process(info, out);
        } catch (TemplateException e) {
            e.printStackTrace(); 
        }
    }
}